# todo
simple todo app to test server workloads on multiple cloud platforms



First after coping files run 

pip install selenium
